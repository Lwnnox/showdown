Ladders are stored here in files named `FORMATID.tsv`.

TSV files are spreadsheets and are best opened with spreadsheet programs such as Excel. Text editors can also handle them, although not as easily.
